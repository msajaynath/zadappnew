import { Component } from '@angular/core';
import { NavController, NavParams, ToastController, } from 'ionic-angular';
import { CreateUserModel } from '../Models/createusermodel';
import { UserService } from '../service/UserServices';
import { ProfileDetails } from '../Models/ProfileDetails'
import { Storage } from '@ionic/storage';
import { Home } from '../home/Home';
import { TranslateService } from 'ng2-translate/ng2-translate';
import { LanguageService } from '../service/language';

@Component({
  selector: 'page-createprofile',
  templateUrl: 'createprofile.html',
  providers: [UserService]
})
export class CreateProfile {
  UserInfo: ProfileDetails;
  PageTitle: any;
  Languages: Array<{ LanguageId: string, LanguageName: string }>;
  createProfile;

  resultText: any;

  constructor(public navCtrl: NavController, public storage: Storage ,public translate: TranslateService, public language: LanguageService, public toastCtrl: ToastController, public userService: UserService, public navParams: NavParams) {
    this.UserInfo = navParams.get('UserInfo');
    this.PageTitle = navParams.get('pageName');
    if (this.PageTitle == 'EditProfile') {
      this.createProfile = new CreateUserModel('', '', this.UserInfo.Name, this.UserInfo.JobDescription, this.UserInfo.ISPrivate,
        this.UserInfo.Language, this.UserInfo.Email, this.UserInfo.PhoneNumber);
    }
    else
      this.createProfile = new CreateUserModel('', '', '', '', false, '', '', '');

    this.Languages = [];
    this.Languages.push({ LanguageId: 'ar', LanguageName: 'Arabic' });
    this.Languages.push({ LanguageId: 'en', LanguageName: 'English' });
  }

  SaveProfile() {
    let isValid = true;
    if(this.createProfile.Name.length == 0){
      this.presentToast("Please add your name");
      isValid = false
    } 
    else if(this.createProfile.JobDescription.length == 0){
      this.presentToast("Please add your Job Description");
      isValid = false
    }  
    else if(this.createProfile.Email.length == 0){
      this.presentToast("Please add your Email");
      isValid = false
    }  
    else if(!this.validateEmail(this.createProfile.Email)){
      this.presentToast("Please add correct Email");
      isValid = false
    } 
    else if(this.createProfile.PhoneNumber.length == 0){
      this.presentToast("Please add your Phone Number");
      isValid = false
    }  
    else if(!this.mobileValidation()){
      this.presentToast("Please add correct Phone number");
      isValid = false
    } 
    else if(this.createProfile.Password.length == 0){
      this.presentToast("Please add your Password");
      isValid = false
    }  
    else if(this.createProfile.ConfirmPassword.length == 0){
      this.presentToast("Please enter ConfirmPassword");
      isValid = false
    }    
    else if(!this.PasswordMatching()){
      this.presentToast("Password doesnot match");
      isValid = false
    } 
    else if(this.createProfile.Language.length == 0){
      this.presentToast("Please enter Language preference");
      isValid = false
    } 
    
    alert(JSON.stringify(this.createProfile));
    this.userService.SaveUser(this.createProfile).then((resultText: any) => {
      debugger;
      this.resultText = resultText

      if (this.resultText.status == true) {
        this.storage.set('LoggedInUserId', this.resultText.id);
        this.storage.set('LoggedInUserDetails',  this.resultText);
        this.translate.use(resultText.Language);
        this.language.setValue(resultText.Language)
        this.navCtrl.setPages([
          { page: Home }
        ])
      }
      else
        alert(this.resultText.message)
    });
  }

  private presentToast(text) {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

  validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
  }

  PasswordMatching(){
    if(this.createProfile.Password == this.createProfile.ConfirmPassword)
      return true;
    else
      return false;
  }

  mobileValidation(){
    return /^\d{10}$/.test(this.createProfile.PhoneNumber)
  }
}
